export default function Home() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '40px' }}>
      <h1 style={{ color: '#2563eb' }}>IntelliFlow AI Solutions</h1>
      <p>AI-powered tools for SMEs in Manufacturing & Retail.</p>
      
      <h2>🚀 Our Products</h2>
      <ul>
        <li>AI Chatbot for Customer Support</li>
        <li>AI Recruitment Tool</li>
        <li>AI Marketing Automation</li>
        <li>AI Financial Forecasting Model</li>
        <li>Supply Chain AI Optimizer</li>
      </ul>

      <h2>💰 Pricing</h2>
      <p>Simple subscription model. Contact us for details.</p>

      <h2>📩 Contact Us</h2>
      <p>Email: hello@intelliflow.ai</p>
    </div>
  )
}
